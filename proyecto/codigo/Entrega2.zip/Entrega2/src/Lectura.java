import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Lectura {
    static ArrayList<Dato> d = new ArrayList<>();
    static double matriz[][] = new double [300][6];
    static double impureza[][] = new double[300][6];


    public static void main(String[] args) throws Exception {
        float inicio = System.currentTimeMillis();

        leer_archivo(seleccionarDataset());
        llenarMatriz(matriz);
        llenarImpureza(matriz);
        menores(impureza);
        float fin = System.currentTimeMillis();
        float total = fin - inicio;
        System.out.println("Tiempo de ejecucion total: " + total + "ms");
        System.out.println();
        System.out.println("Memoria usada para todo el programa:");
        System.out.println("KB: " + (double) (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024);
        System.out.println("MB: " + (double) ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024)/1024);
    }

    public static void leer_archivo(String data) {
        float inicio = System.currentTimeMillis();
        try {
            PrintWriter writer = new PrintWriter("Datos.txt");
            File file = new File(data);
            Scanner scan = new Scanner(file);
            writer.println("Ph\t    soil_temperature\tsoil_moisture   " +
                    "  illuminance   env_temperature   env_humidity\t\t label");
            scan.nextLine();
            String[] str = new String[7];
            System.out.println("Ph\t    soil_temperature\tsoil_moisture   " +
                    "  illuminance   env_temperature   env_humidity\t\t label");
            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] test = line.   split(",");
                for (int j = 0; j < str.length; j++) {
                    if (j >= test.length) {
                        str[j] = "";
                    } else {
                        str[j] = test[j];
                    }
                }

                d.add(new Dato(Double.parseDouble(str[0]), Double.parseDouble(str[1]),
                        Double.parseDouble(str[2]), Double.parseDouble(str[3]),
                        Double.parseDouble(str[4]), Double.parseDouble(str[5]), str[6]));
                for (String s : str) {
                    System.out.print(s + "\t\t\t  ");
                    writer.print(s + " \t\t\t ");
                }
                System.out.println();
                writer.println();
            }
            writer.close();
        } catch (FileNotFoundException e) {
            System.err.println("No encontado" + e.toString());
        }

        float fin = System.currentTimeMillis();
        float total = fin - inicio;
        System.out.println("Tiempo de ejecucion de leer_archivo: " + total + "ms");
        System.out.println();
        System.out.println("Memoria usada para leer_archivo:");
        System.out.println("KB: " + (double) (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024);
        System.out.println("MB: " + (double) ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024)/1024);
    }

    public static String seleccionarDataset() {

        Scanner teclado = new Scanner(System.in);
        String fst = "data_set.csv";
        String snd = "data_set_balanced.csv";
        String trd = "data_set_train.csv";
        String fth = "data_set_test.csv";
        System.out.println("Seleccione el dataset que desea usar.");
        System.out.println("1. " + fst);
        System.out.println("2. " + snd);
        System.out.println("3. " + trd);
        System.out.println("4. " + fth);
        String data = "";
        int a = 0;
        do {
            try {
                a = Integer.parseInt(teclado.nextLine());
                switch (a) {
                    case 1:
                        data = fst;
                        break;
                    case 2:
                        data = snd;
                        break;
                    case 3:
                        data = trd;
                        break;
                    case 4:
                        data = fth;
                        break;
                    default:
                        a = 0;
                        throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                System.err.println("El valor ingresado no es valido. \nIntente nuevamente.");
            }
        } while (a == 0);
        return data;
    }

    public static void llenarMatriz(double [][] matriz) throws Exception {
        //Metodo para llenar la matriz
        for (int i = 0; i < 300 ; i++) {
            for (int j = 0; j < 6; j++) {
                matriz[i][j] = d.get(i).getValue(j);
            }
        }
        //Metodo para imprimir la matriz, puede borrarse si no necesita ser imprimida
        /**for (int i = 0; i < 300 ; i++) {
         for (int j = 0; j < 6; j++) {
         System.out.print(matriz[i][j]+"\t");
         }
         System.out.println();
         }*/
    }

    public static void llenarImpureza(double [][] matriz) {
        //Metodo para llenar la matriz
        int w = 0;
        do {

            double variableParte = matriz[w][0];
            int tiene = 0;
            int noTiene = 0;
            for (int j = 1; j < 300; j++) {
                if (variableParte > matriz[j][0]) {
                    tiene++;
                } else {
                    noTiene++;
                }
            }
            impureza[w][0] = ((double) 1 - ((double) noTiene / 300) * ((double) noTiene / 300)) + (((double) tiene / 300) * ((double) tiene / 300));
            w++;
        } while (w < 300);
        int x = 0;
        do {

            double variableParte = matriz[x][1];
            int tiene = 0;
            int noTiene = 0;
            for (int j = 1; j < 300; j++) {
                if (variableParte > matriz[j][1]) {
                    tiene++;
                } else {
                    noTiene++;
                }
            }
            impureza[x][1] = ((double) 1 - ((double) noTiene / 300) * ((double) noTiene / 300)) + (((double) tiene / 300) * ((double) tiene / 300));
            x++;
        } while (x < 300);
        int y = 0;
        do {

            double variableParte = matriz[y][2];
            int tiene = 0;
            int noTiene = 0;
            for (int j = 1; j < 300; j++) {
                if (variableParte > matriz[j][2]) {
                    tiene++;
                } else {
                    noTiene++;
                }
            }
            impureza[y][2] = ((double) 1 - ((double) noTiene / 300) * ((double) noTiene / 300)) + (((double) tiene / 300) * ((double) tiene / 300));
            y++;
        } while (y < 300);
        int z = 0;
        do {

            double variableParte = matriz[z][3];
            int tiene = 0;
            int noTiene = 0;
            for (int j = 1; j < 300; j++) {
                if (variableParte > matriz[j][3]) {
                    tiene++;
                } else {
                    noTiene++;
                }
            }
            impureza[z][3] = ((double) 1 - ((double) noTiene / 300) * ((double) noTiene / 300)) + (((double) tiene / 300) * ((double) tiene / 300));
            z++;
        } while (z < 300);
        int a = 0;
        do {

            double variableParte = matriz[a][4];
            int tiene = 0;
            int noTiene = 0;
            for (int j = 1; j < 300; j++) {
                if (variableParte > matriz[j][4]) {
                    tiene++;
                } else {
                    noTiene++;
                }
            }
            impureza[a][4] = ((double) 1 - ((double) noTiene / 300) * ((double) noTiene / 300)) + (((double) tiene / 300) * ((double) tiene / 300));
            a++;
        } while (a < 300);
        int b = 0;
        do {

            double variableParte = matriz[b][5];
            int tiene = 0;
            int noTiene = 0;
            for (int j = 1; j < 300; j++) {
                if (variableParte > matriz[j][5]) {
                    tiene++;
                } else {
                    noTiene++;
                }
            }
            impureza[b][5] = ((double) 1 - ((double) noTiene / 300) * ((double) noTiene / 300)) + (((double) tiene / 300) * ((double) tiene / 300));
            b++;
        } while (b < 300);

        //Metodo para imprimir la matriz, puede borrarse si no necesita ser imprimida
        for (int i = 0; i < 300 ; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print(impureza[i][j] + "\t");
            }
            System.out.println();
        }
    }
    public static void menores(double [][] matriz){
        double a=impureza[0][0],b=impureza[0][1],c=impureza[0][2],d=impureza[0][3],e=impureza[0][4],f=impureza[0][5];
        int posa = 0, posb=0, posc=0, posd=0, pose=0, posf=0;
        for (int i = 0; i <300 ; i++) {
            if (impureza[i][0] < a) {
                a = impureza[i][0];
                posa = i;
            }
            if (impureza[i][1] < b) {
                b = impureza[i][1];
                posb = i;
            }
            if(impureza[i][2] < c) {
                c = impureza[i][2];
                posc = i;
            }
            if (impureza[i][3] < d) {
                d = impureza[i][3];
                posd = i;
            }
            if (impureza[i][4] < e) {
                e = impureza[i][4];
                pose = i;
            }
            if (impureza[i][5] < f) {
                f = impureza[i][5];
                posf = i;
            }
        }
        System.out.println("La menor impureza es "+a+" y esta en la posicion "+posa+",0 del archivo");
        System.out.println("La menor impureza es "+b+" y esta en la posicion "+posb+",1 del archivo");
        System.out.println("La menor impureza es "+c+" y esta en la posicion "+posc+",2 del archivo");
        System.out.println("La menor impureza es "+d+" y esta en la posicion "+posd+",3 del archivo");
        System.out.println("La menor impureza es "+e+" y esta en la posicion "+pose+",4 del archivo");
        System.out.println("La menor impureza es "+f+" y esta en la posicion "+posf+",5 del archivo");
    }
}

class Node {
    public Node parent;
    public List<Node> children;
    public Object info;

    public static int maxNrOfChildren;

    public Node (Object info) {
        this.info = info;
        children = new ArrayList<Node>(maxNrOfChildren);
    }

    public void addChild(Node childNode, int position) {
        if (position > maxNrOfChildren) {
            System.err.println("La posicion no puede ser mayor al numero de hijos.");
        } else {
            System.out.println("this.children = " + this.children);
            if (this.children.get(position) != null) {
                System.err.println("Ya existe un nodo hijo en esta posicion.");
            } else {
                childNode.parent = this;
                this.children.set(position, childNode);
            }
        }
    }
}

class Tree {
    public Node root;

    public Tree(int nArity) {
        Node.maxNrOfChildren = nArity;
    }

    public void addNewNode(Node u, Object info, int i) {
        Node child = new Node(info);
        u.addChild(child, i);
    }

    public int numberOfNodesInTree(Node rootNode) {
        int cont = 0;
        cont++;
        if (rootNode.children.size() != 0) {
            for (Node ch:
                    rootNode.children) {
                cont += numberOfNodesInTree(ch);
            }
        }
        return cont;
    }
}

class Dato {

    double ph;
    double soil_temperature;
    double soil_moisture;
    double illuminance;
    double env_temperature;
    double env_humedety;
    String label;

    public Dato(double ph,double soil_temperature, double soil_moisture,double illuminance,double env_temperature,double env_humedety,String label) {
        this.ph = ph;
        this.soil_temperature = soil_temperature;
        this.soil_moisture = soil_moisture;
        this.illuminance = illuminance;
        this.env_temperature = env_temperature;
        this.env_humedety = env_humedety;
        this.label = label;
    }

    public double getPh() {
        return ph;
    }
    public double getSoil_temperature() {
        return soil_temperature;
    }
    public double getSoil_moisture() {
        return soil_moisture;
    }

    public double getIlluminance() {
        return illuminance;
    }

    public double getEnv_temperature() {
        return env_temperature;
    }

    public double getEnv_humedety() {
        return env_humedety;
    }

    public String getLabel() {
        return label;
    }


    public double getValue(int i) throws Exception {
        switch (i) {
            case 0:
                return getPh();
            case 1:
                return getSoil_temperature();
            case 2:
                return getSoil_moisture();
            case 3:
                return getIlluminance();
            case 4:
                return getEnv_temperature();
            case 5:
                return getEnv_humedety();
            default:
                throw new Exception("No existe el tipo de dato mencionado");
        }
    }
}