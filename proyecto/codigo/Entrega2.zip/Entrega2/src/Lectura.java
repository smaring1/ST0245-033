
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Scanner;

public class Lectura {
    static LinkedList<Dato> d = new LinkedList<>();
    public static void main(String[] args) {
        leer_archivo();
    }
    public static void leer_archivo() {
        try {
            PrintWriter writer = new PrintWriter("Datos.txt");
            File file = new File("data_set_test.csv");
            Scanner scan = new Scanner(file);
            writer.println("Ph\t    soil_temperature\tsoil_moisture   " +
                    "  illuminance   env_temperature   env_humidity\t\t label");
            scan.nextLine();
            String[] str = new String[7];
            System.out.println("Ph\t    soil_temperature\tsoil_moisture   " +
                    "  illuminance   env_temperature   env_humidity\t\t label");
            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] test = line.   split(",");
                for (int j = 0; j < str.length; j++) {
                    if (j >= test.length) {
                        str[j] = "";
                    } else {
                        str[j] = test[j];
                    }
                }

                d.add(new Dato(Float.parseFloat(str[0]), Float.parseFloat(str[1]), Float.parseFloat(str[2]), Integer.parseInt(str[3]), Integer.parseInt(str[4]), Integer.parseInt(str[5]), str[6]));
                for (String s : str) {
                    System.out.print(s + "\t\t\t  ");
                    writer.print(s + " \t\t\t ");
                }
                System.out.println();
                writer.println();
            }
            writer.close();
        } catch (FileNotFoundException e) {
            System.err.println("No encontado" + e.toString());
        }
    }
}
class Dato{

    float ph;
    float soil_temperature;
    float soil_moisture;
    int illuminance;
    int env_temperature;
    int env_humedety;
    String label;

    public Dato(float ph,float soil_temperature, float soil_moisture,int illuminance,int env_temperature,int env_humedety,String label ){
        this.ph = ph;
        this.soil_temperature = soil_temperature;
        this.soil_moisture = soil_moisture;
        this.illuminance = illuminance;
        this.env_temperature = env_temperature;
        this.env_humedety = env_humedety;
        this.label = label;
    }

    public float getPh() {
        return ph;
    }
    public float getSoil_temperature() {
        return soil_temperature;
    }
    public float getSoil_moisture() {
        return soil_moisture;
    }

    public int getIlluminance() {
        return illuminance;
    }

    public int getEnv_temperature() {
        return env_temperature;
    }

    public int getEnv_humedety() {
        return env_humedety;
    }

    public String getLabel() {
        return label;
    }
}
