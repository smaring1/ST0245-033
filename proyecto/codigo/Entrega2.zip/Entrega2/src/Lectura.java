
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Lectura {
    static ArrayList<Dato> d = new ArrayList<>();
    static double matriz[][] = new double [300][6];
    public static void main(String[] args) throws Exception {
        float inicio = System.currentTimeMillis();

        leer_archivo(seleccionarDataset());
        System.out.println("Aquí empieza la matriz");
        llenarMatriz(matriz);

        float fin = System.currentTimeMillis();
        float total = fin - inicio;
        System.out.println("Tiempo de ejecucion total: " + total + "ms");
        System.out.println();
        System.out.println("Memoria usada:");
        System.out.println("KB: " + (double) (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024);
        System.out.println("MB: " + (double) ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024)/1024);
    }

    public static void leer_archivo(String data) {
        try {
            PrintWriter writer = new PrintWriter(data);
            File file = new File("data_set_test.csv");
            Scanner scan = new Scanner(file);
            writer.println("Ph\t    soil_temperature\tsoil_moisture   " +
                    "  illuminance   env_temperature   env_humidity\t\t label");
            scan.nextLine();
            String[] str = new String[7];
            System.out.println("Ph\t    soil_temperature\tsoil_moisture   " +
                    "  illuminance   env_temperature   env_humidity\t\t label");
            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] test = line.   split(",");
                for (int j = 0; j < str.length; j++) {
                    if (j >= test.length) {
                        str[j] = "";
                    } else {
                        str[j] = test[j];
                    }
                }

                d.add(new Dato(Float.parseFloat(str[0]), Float.parseFloat(str[1]),
                        Float.parseFloat(str[2]), Integer.parseInt(str[3]),
                        Integer.parseInt(str[4]), Integer.parseInt(str[5]), str[6]));
                for (String s : str) {
                    System.out.print(s + "\t\t\t  ");
                    writer.print(s + " \t\t\t ");
                }
                System.out.println();
                writer.println();
            }
            writer.close();
        } catch (FileNotFoundException e) {
            System.err.println("No encontado" + e.toString());
        }
    }

    public static String seleccionarDataset() {
        Scanner teclado = new Scanner(System.in);
        String fst = "data_set.csv";
        String snd = "data_set_balanced.csv";
        String trd = "data_set_train.csv";
        String fth = "data_set_test.csv";
        System.out.println("Seleccione el dataset que desea usar.");
        System.out.println("1. " + fst);
        System.out.println("2. " + snd);
        System.out.println("3. " + trd);
        System.out.println("4. " + fth);
        String data = "";
        int a = 0;
        do {
            try {
                a = Integer.parseInt(teclado.nextLine());
                switch (a) {
                    case 1:
                        data = fst;
                        break;
                    case 2:
                        data = snd;
                        break;
                    case 3:
                        data = trd;
                        break;
                    case 4:
                        data = fth;
                        break;
                    default:
                        a = 0;
                        throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                System.err.println("El valor ingresado no es valido. \nIntente nuevamente.");
            }
        } while (a == 0);
        return data;
    }

    public static void llenarMatriz(double [][] matriz) throws Exception {
        //Metodo para llenar la matriz
        for (int i = 0; i < 300 ; i++) {
            for (int j = 0; j < 6; j++) {
                matriz[i][j] = d.get(i).getValue(j);
            }
        }
        //Metodo para imprimir la matriz, puede borrarse si no necesita ser imprimida
        for (int i = 0; i < 300 ; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print(matriz[i][j]+"\t");
            }
            System.out.println();
        }
    }
}

class Node {
    public Node parent;
    public List<Node> children;
    public Object info;

    public static int maxNrOfChildren;

    public Node (Object info) {
        this.info = info;
        children = new ArrayList<Node>(maxNrOfChildren);
    }

    public void addChild(Node childNode, int position) {
        if (position > maxNrOfChildren) {
            System.err.println("La posicion no puede ser mayor al numero de hijos.");
        } else {
            System.out.println("this.children = " + this.children);
            if (this.children.get(position) != null) {
                System.err.println("Ya existe un nodo hijo en esta posicion.");
            } else {
                childNode.parent = this;
                this.children.set(position, childNode);
            }
        }
    }
}

class Tree {
    public Node root;

    public Tree(int nArity) {
        Node.maxNrOfChildren = nArity;
    }

    public void addNewNode(Node u, Object info, int i) {
        Node child = new Node(info);
        u.addChild(child, i);
    }

    public int numberOfNodesInTree(Node rootNode) {
        int cont = 0;
        cont++;
        if (rootNode.children.size() != 0) {
            for (Node ch:
                    rootNode.children) {
                cont += numberOfNodesInTree(ch);
            }
        }
        return cont;
    }
}

class Dato {

    float ph;
    float soil_temperature;
    float soil_moisture;
    int illuminance;
    int env_temperature;
    int env_humedety;
    String label;

    public Dato(float ph,float soil_temperature, float soil_moisture,int illuminance,int env_temperature,int env_humedety,String label) {
        this.ph = ph;
        this.soil_temperature = soil_temperature;
        this.soil_moisture = soil_moisture;
        this.illuminance = illuminance;
        this.env_temperature = env_temperature;
        this.env_humedety = env_humedety;
        this.label = label;
    }

    public float getPh() {
        return ph;
    }
    public float getSoil_temperature() {
        return soil_temperature;
    }
    public float getSoil_moisture() {
        return soil_moisture;
    }

    public int getIlluminance() {
        return illuminance;
    }

    public int getEnv_temperature() {
        return env_temperature;
    }

    public int getEnv_humedety() {
        return env_humedety;
    }

    public String getLabel() {
        return label;
    }


    public double getValue(int i) throws Exception {
        switch (i) {
            case 0:
                return getPh();
            case 1:
                return getSoil_temperature();
            case 2:
                return getSoil_moisture();
            case 3:
                return getIlluminance();
            case 4:
                return getEnv_temperature();
            case 5:
                return getEnv_humedety();
            default:
                throw new Exception("No existe el tipo de dato mencionado");
        }
    }
}
