public class Dato {

    double ph;
    double soil_temperature;
    double soil_moisture;
    double illuminance;
    double env_temperature;
    double env_humedety;
    String label;

    public Dato(double ph, double soil_temperature, double soil_moisture, double illuminance, double env_temperature, double env_humedety, String label) {
        this.ph = ph;
        this.soil_temperature = soil_temperature;
        this.soil_moisture = soil_moisture;
        this.illuminance = illuminance;
        this.env_temperature = env_temperature;
        this.env_humedety = env_humedety;
        this.label = label;
    }

    public double getPh() {
        return ph;
    }

    public double getSoil_temperature() {
        return soil_temperature;
    }

    public double getSoil_moisture() {
        return soil_moisture;
    }

    public double getIlluminance() {
        return illuminance;
    }

    public double getEnv_temperature() {
        return env_temperature;
    }

    public double getEnv_humedety() {
        return env_humedety;
    }

    public String getLabel() {
        return label;
    }


    public double getValue(int i) throws Exception {
        switch (i) {
            case 0:
                return getPh();
            case 1:
                return getSoil_temperature();
            case 2:
                return getSoil_moisture();
            case 3:
                return getIlluminance();
            case 4:
                return getEnv_temperature();
            case 5:
                return getEnv_humedety();
            default:
                throw new Exception("No existe el tipo de dato mencionado");
        }
    }
}