import java.util.ArrayList;
import java.util.LinkedList;

public class Node {
    public double algo;
    public double variable;
    public double matriz[][];
    public double impurezas[][];
    public int label[];
    public double impureza;
    public Node izq;
    public Node der;

    public Node(double [][] matrizDeDatos, int []label) {
        matriz = matrizDeDatos;
        impurezas = llenarImpureza(matriz,label);
        this.label = label;
        int columnas = matrizDeDatos[0].length;
        if (columnas > 1) {
            impureza = variableConMenorImpureza(impurezas);
           variable = equivalencia(matriz,impurezas,impureza);
           algo = algo(matriz, variable);
           double[][] matrizIzq = mayores(matriz, (int) algo, variable);
           //LinkedList<Integer> indiM = indicesMayores(matriz, (int) algo, variable);
           double[][] matrizDer = menores(matriz, (int) algo, variable);
           //LinkedList<Integer> indimenor = indicesMenores(matriz, (int) algo, variable);
           //int [] labelIzq = labelMenor(label,indimenor);
            //int [] labelDer = labelMayor(label,indiM);
           if (matrizIzq.length > 0)
              izq = new Node(matrizIzq, label );
           if (matrizDer.length > 0)
              der = new Node(matrizDer,label);
         }
    }

    /**
     * Retorna el número de la variable con la cual se va a trabajar
     * @param matriz
     * @param algo
     * @return
     */
    public static int algo(double[][] matriz, double algo){
        for (int i = 0; i < matriz[0].length ; i++) {
            for (int j = 0; j < matriz.length ; j++) {
                if(matriz[j][i] == algo){
                    return i;
                }
            }
        }
        return 0;
    }

    /**
     * Retorna el valor de la variable con la que se está trabajando
     * @param matriz
     * @param impureza
     * @param valorImpureza
     * @return
     */
    public static double equivalencia(double matriz[][],double [][] impureza, double valorImpureza ){

        for (int j = 0; j <impureza[0].length ; j++) {
            for (int i = 0; i <impureza.length ; i++) {
                if (impureza[i][j] == valorImpureza) {
                    //System.out.println("Está en la posición: " + "[" + j +   "]" + "[" + i + "]");
                    return matriz[i][j];
                }
            }
        }

        return 0;
    }

    /**
     * Una ayuda por si en algún momento necesito la fila donde está la variable
     *
     * @param matriz
     * @param algo
     * @return
     */
    public static int fila(double[][] matriz, double algo){
        for (int i = 0; i < matriz[0].length ; i++) {
            for (int j = 0; j < matriz.length ; j++) {

                if(matriz[j][i] == algo){
                    return j;
                }
            }
        }
        return 0;
    }

    /**
     * Dada una matriz de impureza encuentra la menor.
     * @param impureza5
     * @return
     */
    public static double variableConMenorImpureza(double[][]impureza5) {
        double a = impureza5[0][0];
        for (int i = 0; i < impureza5[0].length ; i++) {
            for (int j = 0; j <impureza5.length; j++) {
                if(impureza5[j][i] < a){
                    a = impureza5[j][i];
                }
            }
        }
        return a;
    }


    /**
     * Recorta la Columna con la que ya trabajamos
     * @param matriz
     * @param colum
     * @return
     */
    public static double[][] recortada (double[][]matriz,int colum) {
        double[][] recortada = new double[matriz.length][(matriz[0].length-1)];
        int w = 0;
        for (int i = 0; i < matriz[0].length ; i++) {
            if (i == colum){
                continue;
            }
            for (int j = 0; j < matriz.length; j++) {
                recortada[j][w] = matriz[j][i];
            }
            w++;
        }
        return recortada;
    }

    /**
     * Este método calcula la impureza de gini.
     * @param matriz
     */
    public static double[][] llenarImpureza(double [][] matriz, int [] label) {
        //Metodo para llenar la matriz
        double[][] impureza5 = new double[matriz.length][matriz[0].length];
        for (int i = 0; i < matriz[0].length ; i++) {
            for (int j = 0; j < matriz.length ; j++) {
                ArrayList<Double> derecha = new ArrayList<>();
                ArrayList<Double> izquierda = new ArrayList<>();
                double variableParte= matriz[j][i];
                int mayores= 0;
                int menores = 0;
                int royaI = 0;
                int noRoyaI = 0;
                int royaD = 0;
                int noRoyaD = 0;
                double impureza;
                double impurezaD;
                double impurezaI;

                for (int k = 0; k < matriz.length ; k++) {
                    if (matriz[k][i] <= variableParte) {
                        if (label[k]==1){
                            royaI++;
                        }else if(label[k]==0){
                            noRoyaI++;
                        }
                        menores++;
                        izquierda.add(matriz[k][i]);
                    } else {
                        if (label[k]==1){
                            royaD++;
                        }else if(label[k]==0){
                            noRoyaD++;
                        }
                        mayores++;
                        derecha.add(matriz[k][i]);
                    }
                }
                impurezaD = (double) 1-(Math.pow(((double)royaD/derecha.size()),2)+ Math.pow(((double)noRoyaD/derecha.size()),2));
                impurezaI = (double) 1-(Math.pow(((double)royaI/izquierda.size()),2)+ Math.pow(((double)noRoyaI/izquierda.size()),2));
                impureza=((menores*impurezaI)+(mayores*impurezaD))/(mayores+menores);
                impureza5[j][i]=impureza;
                System.out.println("Variable"+"["+i+"]"+"["+j+"]" +" Estos son los mayores que "+variableParte+": "+mayores+" y de esos mayores "+royaD+" tienen roya y "+noRoyaD+" no tienen roya");
                System.out.println("Variable"+"["+i+"]"+"["+j+"]" +" Estos son los menores que "+variableParte+": "+menores+" y de esos menores "+royaI+" tienen roya y "+noRoyaI+" no tienen roya");
            }
        }


        /**for (int i = 0; i < impureza5.length ; i++) {
         for (int j = 0; j < 6; j++) {
         System.out.print(impureza5[i][j] + "\t");
         }
         System.out.println();
         }*/
        return impureza5;
    }


    /**
     * Separa los mayores que un valor dado en una columna
     * @param matriz
     * @param colum
     * @param valor
     * @return
     */
    public static double[][]  mayores (double [][] matriz, int colum, double valor){
        LinkedList<Integer> indicesDeLasFilasMayores = new LinkedList();
        for (int i = 0; i < matriz.length  ; i++) {
            if (matriz[i][colum] >= valor)
                indicesDeLasFilasMayores.add(i);
        }
        double [][] grandes = new double[indicesDeLasFilasMayores.size()][matriz[0].length];
        int indice = 0;
        for (int i = 0; i < grandes.length ; i++) {
            for (int j = 0; j < grandes[0].length; j++) {
                grandes[i][j] = matriz[indicesDeLasFilasMayores.get(indice)][j];
            }
            indice++;
        }
        double[][] recorte = recortada(grandes,colum);
        return recorte;
    }

    public static LinkedList<Integer> indicesMayores(double [][] matriz, int colum, double valor){
        LinkedList<Integer> indicesDeLasFilasMayores = new LinkedList();
        for (int i = 0; i < matriz.length  ; i++) {
            if (matriz[i][colum] >= valor)
                indicesDeLasFilasMayores.add(i);
        }
        return indicesDeLasFilasMayores;
    }

    public static LinkedList<Integer> indicesMenores(double [][] matriz, int colum, double valor){
        LinkedList<Integer> indicesDeLasFilasMenores = new LinkedList();
        for (int i = 0; i < matriz.length  ; i++) {
            if (matriz[i][colum] < valor)
                indicesDeLasFilasMenores.add(i);
        }
        return indicesDeLasFilasMenores;
    }

    public static double[][]  menores (double [][] matriz, int colum, double valor){
        LinkedList<Integer> indicesMenores = new LinkedList();
        for (int i = 0; i < matriz.length  ; i++) {
            if (matriz[i][colum] < valor)
                indicesMenores.add(i);
        }
        double [][] pequeños = new double[indicesMenores.size()][matriz[0].length];
        int indice = 0;
        for (int i = 0; i < pequeños.length ; i++) {
            for (int j = 0; j < pequeños[0].length; j++) {
                pequeños[i][j] = matriz[indicesMenores.get(indice)][j];
            }
            indice++;
        }
        double[][] recorte = recortada(pequeños,colum);
        return recorte;
    }

}
