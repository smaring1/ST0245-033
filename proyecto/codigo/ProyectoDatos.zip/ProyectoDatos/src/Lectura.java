import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
/**
 * Código para leer datasets y calcular impurezas para la segunda entrega
 * de Estructuras de Datos y Algoritmos 1
 *
 * @author Simón Marín, Miguel Fernando Ramos
 */

public class Lectura {
    static ArrayList<Dato> datos = new ArrayList<>();
    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        float inicio = System.currentTimeMillis();

        leer_archivo(seleccionarDataset());
        int label[] = llenarLabel();
        double matriz[][] = recolectarDatos();

        Node raizDelArbol = new Node(matriz, label);
        Tree tree = new Tree(raizDelArbol);





        System.out.println("Aquí está la raiz " + tree.toString());


        float fin = System.currentTimeMillis();
        float total = fin - inicio;

        System.out.println("Tiempo de ejecucion total: " + total + "ms");
        System.out.println();
        System.out.println("Memoria usada para todo el programa:");
        System.out.println("KB: " + (double) (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024);
        System.out.println("MB: " + (double) ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024)/1024);
    }


    /**
     * Este método procesa los datasets.
     * @param data es el nombre del archivo .csv a procesar.
     */
    public static void leer_archivo(String data) {
        float inicio = System.currentTimeMillis();
        try {
            PrintWriter writer = new PrintWriter("Datos.txt");
            File file = new File(data);
            Scanner scan = new Scanner(file);
            writer.println("Ph\t    soil_temperature\tsoil_moisture   " +
                    "  illuminance   env_temperature   env_humidity\t\t label");
            scan.nextLine();
            String[] str = new String[7];
            System.out.println("Ph\t    soil_temperature\tsoil_moisture   " +
                    "  illuminance   env_temperature   env_humidity\t\t label");
            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] test = line.split(",");
                for (int j = 0; j < str.length; j++) {
                    if (j >= test.length) {
                        str[j] = "";
                    } else {
                        str[j] = test[j];
                    }
                }

                datos.add(new Dato(Double.parseDouble(str[0]), Double.parseDouble(str[1]),
                        Double.parseDouble(str[2]), Double.parseDouble(str[3]),
                        Double.parseDouble(str[4]), Double.parseDouble(str[5]), (str[6])));
                for (String s : str) {
                    System.out.print(s + "\t\t\t  ");
                    writer.print(s + " \t\t\t ");
                }
                System.out.println();
                writer.println();
            }
            writer.close();
        } catch (FileNotFoundException e) {
            System.err.println("No encontado" + e.toString());
        }

        float fin = System.currentTimeMillis();
        float total = fin - inicio;
        System.out.println("Tiempo de ejecucion de leer_archivo: " + total + "ms");
        System.out.println();
        System.out.println("Memoria usada para leer_archivo:");
        System.out.println("KB: " + (double) (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024);
        System.out.println("MB: " + (double) ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024)/1024);
    }

    /**
     * Este método permite al usuario interactuar con
     * el programa para seleccionar el dataset a procesar.
     * @return el nombre del archivo a procesar.
     */
    public static String seleccionarDataset() {

        Scanner teclado = new Scanner(System.in);
        String fst = "data_set.csv";
        String snd = "data_set_balanced.csv";
        String trd = "data_set_train.csv";
        String fth = "data_set_test.csv";
        System.out.println("Seleccione el dataset que desea usar.");
        System.out.println("1. " + fst);
        System.out.println("2. " + snd);
        System.out.println("3. " + trd);
        System.out.println("4. " + fth);
        String data = "";
        int a = 0;
        do {
            try {
                a = Integer.parseInt(teclado.nextLine());
                switch (a) {
                    case 1:
                        data = fst;
                        break;
                    case 2:
                        data = snd;
                        break;
                    case 3:
                        data = trd;
                        break;
                    case 4:
                        data = fth;
                        break;
                    default:
                        a = 0;
                        throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                System.err.println("El valor ingresado no es valido. \nIntente nuevamente.");
            }
        } while (a == 0);
        return data;
    }

    /**
     * Este método introduce los datos del dataset
     * en una matriz para facilitar el manejo.
     * @throws Exception
     */
    public static double[][] recolectarDatos() throws Exception {
        //Metodo para llenar la matriz
        int filas = datos.size();
        double[][] matriz5 = new double[filas][6];
        for (int i = 0; i < filas ; i++) {
            for (int j = 0; j < 6; j++) {
                matriz5[i][j] = datos.get(i).getValue(j);
            }
        }
        //Metodo para imprimir la matriz, puede borrarse si no necesita ser imprimida
        /**
         for (int i = 0; i < filas ; i++) {
         for (int j = 0; j < 6; j++) {
         System.out.print(matriz5[i][j]+"\t");
         }
         System.out.println();
         }              */
        return matriz5;
    }

    public static int[] llenarLabel(){
        int label5 [];
        int filas = datos.size();
        label5 = new int [filas];
        for (int i = 0; i < filas ; i++) {
            if(datos.get(i).getLabel().compareToIgnoreCase("yes")==0){
                label5[i] = 1;
            }else {
                label5[i]=0;
            }
        }
        //Metodo para imprimir la matriz, puede borrarse si no necesita ser imprimida

        /**for (int a: label5
         ) {
         System.out.println(a);
         }*/

        return label5;
    }

}


