import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
/**
 * Code for Data Structures and Algoritms 1
 * final project.
 *
 * @author Simón Marín, Miguel Fernando Ramos, Mauricio Toro
 */

public class Lectura {
    static ArrayList<Dato> datos = new ArrayList<>();
    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        long inicio = System.currentTimeMillis();

        leer_archivo(seleccionarDataset());
        int label[] = llenarLabel();
        double matriz[][] = recolectarDatos();

        Node raizDelArbol = new Node(matriz, label);
        Tree tree = new Tree(raizDelArbol);

        System.out.println("Aquí está la raiz " + tree.toString());

        long fin = System.currentTimeMillis();
        long total = fin - inicio;

        System.out.println("Tiempo de ejecucion total: " + total + "ms");
        System.out.println();
        System.out.println("Memoria usada para todo el programa:");
        System.out.println("KB: " + (double) (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024);
        System.out.println("MB: " + (double) ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024)/1024);
    }

    /**
     * This method processes the datasets.
     * @param data es el name of the .csv file to process.
     */
    public static void leer_archivo(String data) {
        long inicio_leer = System.currentTimeMillis();
        try {
            PrintWriter writer = new PrintWriter("Datos.txt");
            File file = new File(data);
            Scanner scan = new Scanner(file);
            writer.println("Ph\t    soil_temperature\tsoil_moisture   " +
                    "  illuminance   env_temperature   env_humidity\t\t label");
            scan.nextLine();
            String[] str = new String[7];
            System.out.println("Ph\t    soil_temperature\tsoil_moisture   " +
                    "  illuminance   env_temperature   env_humidity\t\t label");
            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] test = line.split(",");
                for (int j = 0; j < str.length; j++) {
                    if (j >= test.length) {
                        str[j] = "";
                    } else {
                        str[j] = test[j];
                    }
                }

                datos.add(new Dato(Double.parseDouble(str[0]), Double.parseDouble(str[1]),
                        Double.parseDouble(str[2]), Double.parseDouble(str[3]),
                        Double.parseDouble(str[4]), Double.parseDouble(str[5]), (str[6])));
                for (String s : str) {
                    System.out.print(s + "\t\t\t  ");
                    writer.print(s + " \t\t\t ");
                }
                System.out.println();
                writer.println();
            }
            writer.close();
        } catch (FileNotFoundException e) {
            System.err.println("No encontado" + e.toString());
        }

        long fin_leer = System.currentTimeMillis();
        long total_leer = fin_leer - inicio_leer;
        System.out.println("Tiempo de ejecucion de leer_archivo: " + total_leer + "ms");
        System.out.println();
        System.out.println("Memoria usada para leer_archivo:");
        System.out.println("KB: " + (double) (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024);
        System.out.println("MB: " + (double) ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024)/1024);
    }

    /**
     * This method allows the user to interact
     * with the program to select a dataset to process.
     */
    public static String seleccionarDataset() {
        long inicio_selec = System.currentTimeMillis();
        Scanner teclado = new Scanner(System.in);
        String fst = "data_set.csv";
        String snd = "data_set_balanced.csv";
        String trd = "data_set_train.csv";
        String fth = "data_set_test.csv";
        System.out.println("Seleccione el dataset que desea usar.");
        System.out.println("1. " + fst);
        System.out.println("2. " + snd);
        System.out.println("3. " + trd);
        System.out.println("4. " + fth);
        String data = "";
        int a = 0;
        do {
            try {
                a = Integer.parseInt(teclado.nextLine());
                switch (a) {
                    case 1:
                        data = fst;
                        break;
                    case 2:
                        data = snd;
                        break;
                    case 3:
                        data = trd;
                        break;
                    case 4:
                        data = fth;
                        break;
                    default:
                        a = 0;
                        throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                System.err.println("El valor ingresado no es valido. \nIntente nuevamente.");
            }
        } while (a == 0);
        long fin_selec = System.currentTimeMillis();
        long total_selec = fin_selec - inicio_selec;
        System.out.println("Tiempo de ejecución para seleccionarDataset(): " + total_selec + "ms");

        return data;
    }

    /**
     * This methods fills the data from the dataset
     * into a matrix for making it easier to process.
     * @throws Exception
     */
    public static double[][] recolectarDatos() throws Exception {
        long inicio_recol = System.currentTimeMillis();

        //Metodo para llenar la matriz
        int filas = datos.size();
        double[][] matriz5 = new double[filas][6];
        for (int i = 0; i < filas ; i++) {
            for (int j = 0; j < 6; j++) {
                matriz5[i][j] = datos.get(i).getValue(j);
            }
        }
        //Metodo para imprimir la matriz, puede borrarse si no necesita ser imprimida
        /*
         for (int i = 0; i < filas ; i++) {
         for (int j = 0; j < 6; j++) {
         System.out.print(matriz5[i][j]+"\t");
         }
         System.out.println();
         }*/
        long fin_recol = System.currentTimeMillis();
        long total_recol = fin_recol - inicio_recol;
        System.out.println("Tiempo de ejecución para recolectarDatos(): " + total_recol + "ms");
        return matriz5;
    }

    /**
     * This method fills a matrix with
     * the labels processed by the program.
     * @return matrix with labels.
     */
    public static int[] llenarLabel() {
        long inicio_llenar = System.currentTimeMillis();

        int label5 [];
        int filas = datos.size();
        label5 = new int [filas];
        for (int i = 0; i < filas ; i++) {
            if (datos.get(i).getLabel().compareToIgnoreCase("yes") == 0) {
                label5[i] = 1;
            } else {
                label5[i]=0;
            }
        }
        //Metodo para imprimir la matriz, puede borrarse si no necesita ser imprimida

        /*for (int a: label5
         ) {
         System.out.println(a);
         }*/

        long fin_llenar = System.currentTimeMillis();
        long total_llenar = fin_llenar - inicio_llenar;
        System.out.println("Tiempo de ejecución para llenarLabel(): " + total_llenar + "ms");

        return label5;
    }
}


